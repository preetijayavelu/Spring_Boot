package com.myapp.ecs.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.myapp.ecs.model.Customer;
import com.myapp.ecs.service.CustomerService;

@Controller
public class EcsSpringController {
	
	@Qualifier("esi1")
	@Autowired
	private CustomerService customerService;

	public EcsSpringController() {
		System.out.println("EmsSpringController created...");
	}

	@RequestMapping("/scustomers")
	public ModelAndView getAllCustomers(){
	return new ModelAndView("customerList", "customers", customerService.findAllCustomers());	
	}
	
	
	@RequestMapping("/scustomers/edit/{id}")
	public String editCustomer(@PathVariable("id") int customerId,ModelMap map){
		System.out.println("In editcustomer "+customerId);
		
		map.addAttribute("customer",customerService.findCustomer(customerId));
		map.addAttribute("customers",customerService.findAllCustomers());
			
	return  "editCustomer";			
	}
	
	
	@RequestMapping("/scustomers/delete")
	public String deleteCustomer(@RequestParam("customerId") int customerId,ModelMap map){
	
		System.out.println("In deletecustomer "+customerId);
		
		
		customerService.deleteCustomer(customerId);
	
		map.addAttribute("customers",customerService.findAllCustomers());
		
		
	     return  "customerList";
			
	}
	
	
	@RequestMapping("/scustomers/new")
	public String newCustomer(ModelMap map){
	
		map.addAttribute("customer",new Customer());
		map.addAttribute("customers",customerService.findAllCustomers());
	
	   return  "addCustomer";
			
	}
	
	
	@RequestMapping(value="/scustomers/add",method=RequestMethod.POST)
	public String addCustomer(Customer customer,ModelMap map){
	
		customerService.addCustomer(customer);
		
		map.addAttribute("customers",customerService.findAllCustomers());
	
	   return  "customerList";
			
	}
	
	
	@RequestMapping(value="/scustomers/update",method=RequestMethod.POST)
	
	public String updateCustomer(Customer customer,ModelMap map){
	
		customerService.updateCustomer(customer);
		
		map.addAttribute("customers",customerService.findAllCustomers());
	
	   return  "customerList";
			
	}
	
}

