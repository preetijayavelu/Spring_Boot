package com.myapp.ecs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myapp.ecs.model.Customer;
import com.myapp.ecs.reposiotry.CustomerJPARepository;
import com.myapp.ecs.service.CustomerService;

@Service("esi1")
public class CustomerServiceImpl1 implements CustomerService{
	
	
		@Autowired
		private CustomerJPARepository repository;

		public CustomerServiceImpl1() {
			System.out.println("CustomerServiceImpl1 created.,.....");
		}

		@Override
		public Customer findCustomer(int customerId) {
			// TODO Auto-generated method stub
			return repository.findById(customerId).get();
		}

		@Override
		public boolean deleteCustomer(int customerId) {

			Customer e = repository.findById(customerId).get();

			if (e != null) {
				repository.delete(e);
				return true;
			}

			return false;
		}

		@Override
		public boolean updateCustomer(Customer customer) {

			Customer e = repository.findById(customer.getCustomerId()).get();

			if (e != null) {
				repository.save(customer);
				return true;
			}

			return false;
		}

		@Override
		public boolean addCustomer(Customer customer) {
			// TODO Auto-generated method stub
			return repository.save(customer) == customer;
		}

		@Override
		public List<Customer> findAllCustomers() {

			return repository.findAll();
		}
	}
