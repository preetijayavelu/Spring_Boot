package com;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class EcsSpringBootApplication {

	public EcsSpringBootApplication() {
	System.out.println("Ecs spring Boot application created....");
	}
	
		
	public static void main(String[] args) {
		SpringApplication.run(EcsSpringBootApplication.class, args);
	}
}